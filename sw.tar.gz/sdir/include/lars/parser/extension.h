#pragma once

#include <lars/glue.h>

namespace lars{
  namespace extensions{
    std::shared_ptr<Extension> parser();
  }
}
